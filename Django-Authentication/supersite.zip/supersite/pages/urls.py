from django.urls import path
from .views import homePageView, loginView, logout_user, private_page, secureView, signUpView

urlpatterns = [
    path('', homePageView, name="home"),
    path('login/', loginView, name="login"),
    path('signup/', signUpView, name="signup"),
    path('secure/', secureView, name="secure"),
    path('logout/', logout_user, name="logout"),
    path('private/', private_page, name="private_page"),
]