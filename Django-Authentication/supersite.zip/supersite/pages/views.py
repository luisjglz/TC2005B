from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login, logout
from django.contrib import messages
from django.contrib.auth.forms import UserCreationForm
from .forms import RegisterUserForm

def homePageView(request):
    return render(request, 'pages/index.html', {})


def loginView(request):
    if request.method == "POST":
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            return redirect('secure')
        else:
            messages.error(request, ('Bad login'))
            return redirect('login')        
    else:
        return render(request, 'pages/login.html', {})

def signUpView(request):
    if request.method == "POST":
        print('hi')
        #form = UserCreationForm(request.POST)
        form = RegisterUserForm(request.POST)
        if form.is_valid():
            form.save()
            username = form.cleaned_data['username']
            password = form.cleaned_data['password1']
            user = authenticate(username=username, password=password)
            login(request,user)
            messages.success(request, ('Registration seccessful'))
            return redirect('secure') 
    else:
        #form = UserCreationForm()
        form = RegisterUserForm()
    return render(request, 'pages/signup.html', {'form':form})

def secureView(request):
    return render(request, 'pages/secure.html', {})

def logout_user(request):
    logout(request)
    messages.success(request, ('Logged out'))
    return redirect('login')

def private_page(request):
    if request.user.is_authenticated:
        return render(request, 'pages/private.html')
    else:
        return render(request, 'pages/index.html')